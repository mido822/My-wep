
function askAI() {
    let question = document.getElementById("question").value;
    if (question.trim() === "") {
        document.getElementById("answer").innerHTML = "❌ الرجاء كتابة سؤال";
    } else {
        document.getElementById("answer").innerHTML = "🤖 جاري المعالجة... (هنا سيتم ربط API لاحقًا)";
    }
}
